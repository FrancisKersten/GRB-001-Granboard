import {initializeApp} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import {getAuth,signInAnonymously} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import {getDatabase,ref,onValue,runTransaction,onDisconnect,set,remove} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-database.js';
const app=initializeApp({apiKey:"AIzaSyBTQnZVMiyrQA4fYj0S3R0bMwgOlpfYcIk",authDomain:"granboard-sync.firebaseapp.com",databaseURL:"https://granboard-sync-default-rtdb.europe-west1.firebasedatabase.app",projectId:"granboard-sync",storageBucket:"granboard-sync.firebasestorage.app",messagingSenderId:"245426604744",appId:"1:245426604744:web:13f43275c1364c3b9133fd"});
const db=getDatabase(app),auth=getAuth(app),$=id=>document.getElementById(id),KEY='gb-proto-v01-identity';
let uid='',identity='',favorite=localStorage.getItem(KEY)||'',players={},state=null,room='',roomRef=null,stop=null,presenceStop=null,presenceRef=null,connectionGeneration=0,online=false,busy=false;
const roster=ref(db,'granboardV005/players');
const audio={hit:'assets/hit.wav',switch:'assets/switch.wav',miss:'assets/miss.wav'};
function sound(k){try{const a=new Audio(audio[k]);a.volume=.3;a.play().catch(()=>{});}catch{}}
function error(e){$('connection').textContent='Erreur Firebase : '+(e.code||e.message);note(String(e.message||e));}
function page(id){for(const k of ['menu','setup','manage','soon'])$(k).classList.toggle('hidden',k!==id);if(id==='menu')window.dispatchEvent(new Event('granboard-menu'))}
function refresh(){const sel=$('identity');const old=identity;sel.replaceChildren(new Option('Choisir un joueur',''));for(const [id,n] of Object.entries(players).sort((a,b)=>a[1].localeCompare(b[1])))sel.add(new Option(n,id));identity=players[old]?old:players[favorite]?favorite:Object.keys(players).find(k=>players[k]===favorite)||'';sel.value=identity;$('saved').textContent='Habituel : '+(players[favorite]||Object.values(players).find(n=>n===favorite)||'non défini');$('playerList').replaceChildren();for(const [id,n] of Object.entries(players)){const row=document.createElement('div');row.className='line';const label=document.createElement('span');label.textContent=n;const edit=document.createElement('button');edit.textContent='Modifier';edit.onclick=()=>changePlayer(id,n);const del=document.createElement('button');del.textContent='Supprimer';del.className='danger';del.onclick=async()=>{if(confirm('Supprimer '+n+' ?'))try{await remove(ref(db,'granboardV005/players/'+id))}catch(e){error(e)}};row.append(label,edit,del);$('playerList').append(row)} }
async function changePlayer(id,old=''){const n=prompt('Nom du joueur',old)?.trim();if(!n)return;if(n.length>40)return alert('40 caractères maximum');try{await runTransaction(roster,p=>{p=p||{};if(Object.entries(p).some(([k,v])=>k!==id&&v.toLowerCase()===n.toLowerCase()))return;return {...p,[id]:n}}).then(r=>{if(!r.committed)alert('Nom déjà utilisé')})}catch(e){error(e)}}
$('identity').onchange=()=>{identity=$('identity').value};$('saveIdentity').onclick=()=>{if(!identity)return alert('Choisis un joueur');favorite=identity;localStorage.setItem(KEY,identity);refresh()};$('add').onclick=()=>changePlayer(crypto.randomUUID());$('manageBtn').onclick=()=>page('manage');$('two').onclick=()=>page('soon');$('test').onclick=()=>{if(!identity)return alert('Choisis un joueur');page('setup')};document.querySelectorAll('.back').forEach(b=>b.onclick=()=>page('menu'));
async function init(){try{await signInAnonymously(auth);uid=auth.currentUser.uid;await runTransaction(roster,p=>p||{jeremy:'Jérémy',francis:'Francis',alice:'Alice',bob:'Bob',denis:'Denis'});onValue(roster,s=>{players=s.val()||{};refresh()},error);onValue(ref(db,'.info/connected'),s=>{online=s.val()===true;$('connection').textContent=online?'Firebase connecté':'Firebase déconnecté';if(state)render()});}catch(e){error(e)}}
const order=[20,1,18,4,13,6,10,15,2,17,3,19,7,16,8,11,14,9,12,5];
function polar(r,a){return [r*Math.sin(a),-r*Math.cos(a)]}
function wedge(r1,r2,a1,a2){const [x1,y1]=polar(r1,a1),[x2,y2]=polar(r2,a1),[x3,y3]=polar(r2,a2),[x4,y4]=polar(r1,a2);return `M ${x1} ${y1} L ${x2} ${y2} A ${r2} ${r2} 0 0 1 ${x3} ${y3} L ${x4} ${y4} A ${r1} ${r1} 0 0 0 ${x1} ${y1} Z`}
const sectors=new Map();
const dartPositions=new Map();
let dartLayer=null;
const hitShades=['','#ffe6a0','#dfa33c','#86500c'];
function registerSector(code,element,r1=0,r2=0,angle=0){sectors.set(code,element);element.dataset.originalFill=element.getAttribute('fill');dartPositions.set(code,{r1,r2,angle});}
function paintDarts(){
  if(!dartLayer)return;
  dartLayer.replaceChildren();
  if(!state)return;
  const counts=new Map();
  for(const code of (state.hits[state.turn]||[])){
    const pos=dartPositions.get(code);
    if(!pos)continue;
    const index=counts.get(code)||0;
    counts.set(code,index+1);
    // Pointes dans le secteur exact; corps volontairement plus grands et lisibles.
    // Les trois fléchettes sont légèrement écartées lorsque le secteur se répète.
    const offsets=[-.23,0,.23];
    const ringWidth=pos.r2-pos.r1;
    const r=pos.r1+ringWidth*(.5+offsets[index%3]*.5);
    const a=pos.angle+(index%3-1)*.065;
    const [x,y]=polar(r,a);
    const g=svg('g',{transform:`translate(${x} ${y}) rotate(${a*180/Math.PI}) scale(2)`,'pointer-events':'none'},dartLayer);
    // La pointe touche le secteur; le reste de la fléchette est dessiné vers le bas.
    svg('path',{d:'M 0 0 L -1.8 8 L 1.8 8 Z',fill:'#dbe4ed',stroke:'#111827','stroke-width':.8},g);
    svg('path',{d:'M -3 8 L -3.6 21 Q 0 24 3.6 21 L 3 8 Z',fill:'#c6d2dc',stroke:'#1f2937','stroke-width':1},g);
    svg('path',{d:'M -2.2 10 L -2.2 20 M 0 10 L 0 21 M 2.2 10 L 2.2 20',fill:'none',stroke:'#64748b','stroke-width':.9},g);
    svg('path',{d:'M -1.3 23 L -1.3 35 L 1.3 35 L 1.3 23 Z',fill:'#f5c542',stroke:'#374151','stroke-width':.8},g);
    svg('path',{d:'M 0 34 Q -8 27 -11 41 L -7 53 L 0 47 L 7 53 L 11 41 Q 8 27 0 34 Z',fill:'#f43f5e',stroke:'#fff1f2','stroke-width':1.3},g);
    svg('path',{d:'M 0 34 L 0 47 M -9 40 L 0 44 L 9 40',fill:'none',stroke:'#7f1d1d','stroke-width':1},g);
  }
}
function paintSectors(){
  const counts=new Map();
  if(state){for(const code of (state.hits[state.turn]||[])){if(sectors.has(code))counts.set(code,(counts.get(code)||0)+1)}}
  for(const [code,element] of sectors){const count=Math.min(counts.get(code)||0,3);element.setAttribute('fill',count?hitShades[count]:element.dataset.originalFill);element.setAttribute('stroke',count?'#fff2c6':'#82909b');element.setAttribute('stroke-width',count?1.8:.8);element.setAttribute('aria-label',code+' : '+(counts.get(code)||0)+' impact(s)')}
  paintDarts();
}
const NS='http://www.w3.org/2000/svg';function svg(tag,attrs,parent){let e=document.createElementNS(NS,tag);for(let [k,v] of Object.entries(attrs))e.setAttribute(k,v);parent.append(e);return e}
function drawBoard(){const b=$('board');svg('circle',{cx:0,cy:0,r:220,fill:'#101820',stroke:'#8291a5','stroke-width':3},b);for(let i=0;i<20;i++){let n=order[i],a1=(i-.5)*Math.PI/10,a2=(i+.5)*Math.PI/10;const rings=[[16,99,'S'+String(n).padStart(2,'0')+'I',n],[99,112,'T'+String(n).padStart(2,'0'),n*3],[112,164,'S'+String(n).padStart(2,'0')+'E',n],[164,178,'D'+String(n).padStart(2,'0'),n*2]];for(let j=0;j<rings.length;j++){const [r1,r2,code,score]=rings[j];let fill=j===1||j===3?(i%2?'#1b965c':'#c63444'):(i%2?'#efe6c9':'#222b36');let p=svg('path',{d:wedge(r1,r2,a1,a2),fill,stroke:'#82909b','stroke-width':.8},b);registerSector(code,p,r1,r2,i*Math.PI/10);p.onclick=()=>hit(code,score)}let [x,y]=polar(199,i*Math.PI/10);let t=svg('text',{x,y,fill:'white','font-size':15,'font-weight':'bold','text-anchor':'middle','dominant-baseline':'middle','pointer-events':'none'},b);t.textContent=n}for(let [r,fill,code,score] of [[16,'#1b965c','SBULL',25],[7,'#c63444','DBULL',50]]){let c=svg('circle',{cx:0,cy:0,r,fill,stroke:'#82909b','stroke-width':.8},b);registerSector(code,c,code==='DBULL'?0:7,code==='DBULL'?7:16,0);c.onclick=()=>hit(code,score)}dartLayer=svg('g',{id:'dart-layer'},b)}drawBoard();
function note(msg){const l=$('log');l.textContent=`${new Date().toLocaleTimeString()} ${msg}\n`+l.textContent.slice(0,4500)}
function render(){if(!state)return;paintSectors();for(let i=0;i<2;i++){$('p'+(i+1)).className='player'+(state.turn===i?' active':'');$('p'+(i+1)).replaceChildren();const strong=document.createElement('strong');strong.textContent=state.players[i]||'En attente…';const score=document.createElement('div');score.className='score';score.textContent=state.scores[i];const hits=document.createElement('div');hits.className='hits';hits.textContent='Impacts : '+((state.hits[i]||[]).join(' · ')||'—');$('p'+(i+1)).append(strong,score,hits)}$('turn').textContent=`Fléchettes : ${state.darts}/3`;const i=state.ids.indexOf(identity),j=1-i;const opponent=state.players[j]||'Adversaire';let msg=!online?'Connexion Firebase perdue — partie en pause':!state.ids[j]?'En attente de l’adversaire':state.departed?.[j]?opponent+' a quitté la partie — partie interrompue':!state.present?.[j]?opponent+' est déconnecté — partie en pause':!state.present?.[i]?'Reconnexion en cours…':'';$('presence').textContent=msg;$('presence').classList.toggle('hidden',!msg);$('status').textContent=msg?'Partie en pause':'Au tour de : '+state.players[state.turn];$('miss').disabled=!canPlay()||state.darts>=3;$('next').disabled=!canPlay()||state.darts!==3;$('reset').disabled=!canPlay();$('undo').disabled=!canCorrect()||!state.history?.length;$('manual').disabled=!canPlay()||state.darts>=3;}
function member(s){return s?.ids?.findIndex((id,i)=>id===identity&&s.owners?.[i]===uid)??-1}
function ready(s){return member(s)>=0&&s.ids.length===2&&s.present?.[0]===true&&s.present?.[1]===true&&!s.departed?.[0]&&!s.departed?.[1]}
function canCorrect(){return online&&!busy&&ready(state)}
function canPlay(){return canCorrect()&&member(state)===state.turn}
function normalize(s){if(!s)return null;s.hits=[s.hits?.[0]||[],s.hits?.[1]||[]];s.scores=s.scores||[0,0];s.history=Object.values(s.history||{});return s}
function snapshot(s){return {scores:[...s.scores],hits:s.hits.map(h=>[...h]),turn:s.turn,darts:s.darts}}
function applyAction(s,action){s=normalize(s);if(action.type==='undo'){const previous=s.history.pop();if(!previous)return;const history=s.history;Object.assign(s,normalize(previous));s.history=history; }else if(action.type==='hit'){if(s.darts>=3)return;s.history.push(snapshot(s));s.scores[s.turn]+=action.score;s.hits[s.turn].push(action.code);s.darts++}else if(action.type==='next'){if(s.darts!==3)return;s.turn=1-s.turn;s.darts=0;s.hits=[[],[]]}else if(action.type==='reset'){s.scores=[0,0];s.hits=[[],[]];s.turn=0;s.darts=0;s.history=[]}else return;s.revision=(s.revision||0)+1;s.last=action.type;return s}
async function emit(action){if(action.type==='undo'?!canCorrect():!canPlay())return;busy=true;const revision=state.revision;render();try{const result=await runTransaction(roomRef,s=>{if(!ready(s)||s.revision!==revision||(action.type!=='undo'&&member(s)!==s.turn))return;return applyAction(s,action)},{applyLocally:false});if(!result.committed)note('Action non validée : état modifié ou connexion perdue.')}catch(e){error(e)}finally{busy=false;if(state)render()}}
function hit(code,score){emit({type:'hit',code,score})}
$('miss').onclick=()=>hit('MISS',0);$('next').onclick=()=>emit({type:'next'});$('reset').onclick=()=>{if(confirm('Réinitialiser la partie et son historique ?'))emit({type:'reset'})};$('undo').onclick=()=>emit({type:'undo'});$('manual').onclick=()=>{const code=$('manualCode').value;const score=code==='MISS'?0:code==='SBULL'?25:code==='DBULL'?50:Number(code.slice(1,3))*(code[0]==='T'?3:code[0]==='D'?2:1);hit(code,score)};
for(const code of [...sectors.keys(),'MISS'])$('manualCode').add(new Option(code,code));
$('join').onclick=async()=>{if(!online||!uid||!players[identity])return alert('Connexion Firebase et joueur requis');if(roomRef)return;room=$('room').value.trim().toUpperCase();if(!/^[A-Z0-9_-]{1,30}$/.test(room))return alert('Nom de salon : lettres, chiffres, tirets');const r=ref(db,'granboardV005/roomsV006/'+room);$('join').disabled=true;try{const result=await runTransaction(r,s=>{if(!s)return {ids:[identity],players:[players[identity]],owners:[uid],present:[false],turn:0,darts:0,scores:[0,0],revision:0};if(s.ids.includes(identity)){const i=s.ids.indexOf(identity);if(s.present?.[i]&&s.owners[i]!==uid)return;s.owners[i]=uid;s.departed=s.departed||{};s.departed[i]=false;return s}if(s.ids.length>=2)return;s.ids.push(identity);s.players.push(players[identity]);s.owners.push(uid);s.present=s.present||[false];s.present[1]=false;return s});if(!result.committed){alert('Salon complet ou joueur déjà connecté');return}roomRef=r;const i=result.snapshot.val().ids.indexOf(identity);presenceRef=ref(db,'granboardV005/roomsV006/'+room+'/present/'+i);await onDisconnect(presenceRef).set(false);await set(presenceRef,true);presenceStop=onValue(ref(db,'.info/connected'),async snap=>{const target=presenceRef;const generation=++connectionGeneration;if(snap.val()&&target)try{await onDisconnect(target).set(false);if(target===presenceRef&&generation===connectionGeneration)await set(target,true)}catch(e){error(e)}});stop=onValue(r,s=>{const prev=state?.revision;state=normalize(s.val());if(!state)return;while(state.players.length<2)state.players.push('En attente…');if(prev!==undefined&&prev!==state.revision){sound(state.last==='hit'?'hit':'switch');note('État synchronisé · '+state.last)}render()},error);$('game').classList.remove('hidden');$('room').disabled=true;$('leave').disabled=false;note('Salon '+room+' · '+players[identity]);}catch(e){error(e);await leave()}finally{$('join').disabled=!!roomRef}};
async function leave(){stop?.();presenceStop?.();connectionGeneration++;if(presenceRef&&online)try{await runTransaction(roomRef,s=>{const i=member(s);if(i<0)return;s.present[i]=false;s.departed=s.departed||{};s.departed[i]=true;return s},{applyLocally:false});await onDisconnect(presenceRef).cancel()}catch(e){error(e)}roomRef=null;presenceRef=null;state=null;$('game').classList.add('hidden');$('room').disabled=false;$('join').disabled=false;$('leave').disabled=true;paintSectors()}
$('leave').onclick=leave;$('backGame').onclick=async()=>{await leave();page('menu')};init();
