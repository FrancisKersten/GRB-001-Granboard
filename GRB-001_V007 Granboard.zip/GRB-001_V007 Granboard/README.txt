GRB-001 V006
Même configuration Firebase et mêmes règles V005. Liste des joueurs conservée. Salons V006 isolés des anciens salons. Annulation successive des hits (y compris après changement de tour), correction manuelle, départ volontaire et perte de connexion. Reconnexion au même salon avec le même joueur. Réinitialisation efface historique. TWO LINES coming soon. Tests réels sur deux appareils nécessaires.

V007 : contrôle version.json au lancement, retour menu et reprise ; contrôle manuel ; mise à jour volontaire hors partie. Conserve les chemins Firebase V006 et les préférences. Pour chaque future version, actualiser version.json, current dans update.js, les références de cache et le numéro affiché.
