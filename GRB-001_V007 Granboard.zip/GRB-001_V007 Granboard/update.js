(() => {
const current = 'V007';
const $ = id => document.getElementById(id);
const dialog = $('updateDialog');
let pending = null, dismissed = null, checking = false;
const safe = () => !$('menu').classList.contains('hidden') && $('game').classList.contains('hidden');
const number = v => Number(v.slice(1));
async function check(manual = false) {
 if (!safe() || checking) return;
 checking = true;
 if (manual) $('updateStatus').textContent = 'Vérification…';
 try {
  const url = new URL('version.json', location.href);
  url.searchParams.set('_', Date.now());
  const response = await fetch(url, {cache:'no-store'});
  if (!response.ok) throw new Error('HTTP '+response.status);
  const {version} = await response.json();
  if (!/^V[0-9]{3,}$/.test(version)) throw new Error('Version invalide');
  if (number(version) > number(current)) {
   pending = version;
   $('updateStatus').textContent = 'Nouvelle version : '+version;
   if (safe() && !dialog.open && (manual || dismissed !== version)) {
    $('updateMessage').textContent = 'Version actuelle : '+current+' · Nouvelle version : '+version;
    dialog.showModal();
   }
  } else { pending = null; $('updateStatus').textContent = number(version) === number(current) ? 'Version '+current+' à jour' : 'Version publiée plus ancienne : '+version; }
 } catch(e) { $('updateStatus').textContent = 'Vérification indisponible. Réessaie plus tard.'; }
 finally { checking = false; }
}
$('checkUpdate').onclick = () => check(true);
$('updateLater').onclick = () => { dismissed = pending; dialog.close(); };
dialog.addEventListener('cancel', () => { dismissed = pending; });
$('updateNow').onclick = () => {
 if (!safe() || !pending) { dialog.close(); return; }
 const url = new URL(location.href); url.searchParams.set('v', pending); url.searchParams.set('_', Date.now()); location.replace(url.href);
};
window.addEventListener('granboard-menu', () => check());
window.addEventListener('pageshow', () => check());
document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
check();
})();
