GranBoard JEU-TEST — prototype Web 0.1

Inclus : identité habituelle locale, cible graphique interactive, scores, trois fléchettes, changement de joueur, remise à zéro, journal, salon local de test via BroadcastChannel, sons originaux et mapping d'origine conservé pour la prochaine étape.

IMPORTANT : pas encore de connexion Bluetooth, Firebase, ni vidéo. Deux fenêtres/onglets du même navigateur sur la même machine peuvent partager un salon. Pas de synchronisation entre appareils dans cette version.

Pour tester sur Windows ou Mac : ouvrir un terminal dans ce dossier et lancer : python -m http.server 8000
Puis visiter http://localhost:8000 dans deux onglets. Pour deux identités différentes, utiliser deux profils de navigateur séparés (attention : BroadcastChannel ne traverse pas les profils isolés). Pour le test synchronisé sur un seul navigateur, ouvrir deux onglets et conserver la même identité de profil, ou utiliser des identités temporaires dans une future version.

Pour tester sur iPad/Acer/iPhone : déployer le dossier sur Netlify Drop en HTTPS. Cette version fonctionne sans serveur de jeu, mais la synchronisation inter-appareils attend l'intégration Firebase.

SÉCURITÉ : la clé privée Firebase présente dans le ZIP Python d'origine n'est PAS incluse dans ce prototype. Révoquer cette clé avant toute publication du projet d'origine.

V0.3 : coloration et fléchettes limitées au tour courant ; effacement au bouton Joueur suivant.

V0.4 : fléchettes agrandies, pointe métallique, corps strié, tige et ailettes rouges. Effacement au tour suivant conservé.
