'use strict';
const NAMES=['Jérémy','Francis','Alice','Bob','Denis'];
const $=id=>document.getElementById(id);
const KEY='gb-proto-v01-identity';
const uid=crypto.randomUUID?.()||String(Math.random());
let identity=localStorage.getItem(KEY)||'', room='', channel=null, state=null, seq=0;
const audio={hit:'assets/hit.wav',switch:'assets/switch.wav',miss:'assets/miss.wav'};
function sound(k){try{const a=new Audio(audio[k]);a.volume=.3;a.play().catch(()=>{});}catch{}}
function options(el,names){el.innerHTML='';for(const name of names){const o=document.createElement('option');o.value=name;o.textContent=name;el.append(o)}}
options($('identity'),NAMES);options($('opponent'),NAMES);if(identity&&NAMES.includes(identity))$('identity').value=identity;else identity='';
function showSaved(){$('saved').textContent=identity?'Joueur habituel enregistré : '+identity:'Aucun joueur habituel enregistré pour ce navigateur.'; $('opponent').value=NAMES.find(n=>n!==$('identity').value)||NAMES[0]}
showSaved();$('identity').addEventListener('change',showSaved);
$('saveIdentity').onclick=()=>{identity=$('identity').value;localStorage.setItem(KEY,identity);showSaved()};
const order=[20,1,18,4,13,6,10,15,2,17,3,19,7,16,8,11,14,9,12,5];
function polar(r,a){return [r*Math.sin(a),-r*Math.cos(a)]}
function wedge(r1,r2,a1,a2){const [x1,y1]=polar(r1,a1),[x2,y2]=polar(r2,a1),[x3,y3]=polar(r2,a2),[x4,y4]=polar(r1,a2);return `M ${x1} ${y1} L ${x2} ${y2} A ${r2} ${r2} 0 0 1 ${x3} ${y3} L ${x4} ${y4} A ${r1} ${r1} 0 0 0 ${x1} ${y1} Z`}
const sectors=new Map();
const dartPositions=new Map();
let dartLayer=null;
const hitShades=['','#ffe6a0','#dfa33c','#86500c'];
function registerSector(code,element,r1=0,r2=0,angle=0){sectors.set(code,element);element.dataset.originalFill=element.getAttribute('fill');dartPositions.set(code,{r1,r2,angle});}
function paintDarts(){
  if(!dartLayer)return;
  dartLayer.replaceChildren();
  if(!state)return;
  const counts=new Map();
  for(const code of state.hits[state.turn]){
    const pos=dartPositions.get(code);
    if(!pos)continue;
    const index=counts.get(code)||0;
    counts.set(code,index+1);
    // Pointes dans le secteur exact; corps volontairement plus grands et lisibles.
    // Les trois fléchettes sont légèrement écartées lorsque le secteur se répète.
    const offsets=[-.23,0,.23];
    const ringWidth=pos.r2-pos.r1;
    const r=pos.r1+ringWidth*(.5+offsets[index%3]*.5);
    const a=pos.angle+(index%3-1)*.065;
    const [x,y]=polar(r,a);
    const g=svg('g',{transform:`translate(${x} ${y}) rotate(${a*180/Math.PI})`,'pointer-events':'none'},dartLayer);
    // La pointe touche le secteur; le reste de la fléchette est dessiné vers le bas.
    svg('path',{d:'M 0 0 L -1.8 8 L 1.8 8 Z',fill:'#dbe4ed',stroke:'#111827','stroke-width':.8},g);
    svg('path',{d:'M -3 8 L -3.6 21 Q 0 24 3.6 21 L 3 8 Z',fill:'#c6d2dc',stroke:'#1f2937','stroke-width':1},g);
    svg('path',{d:'M -2.2 10 L -2.2 20 M 0 10 L 0 21 M 2.2 10 L 2.2 20',fill:'none',stroke:'#64748b','stroke-width':.9},g);
    svg('path',{d:'M -1.3 23 L -1.3 35 L 1.3 35 L 1.3 23 Z',fill:'#f5c542',stroke:'#374151','stroke-width':.8},g);
    svg('path',{d:'M 0 34 Q -8 27 -11 41 L -7 53 L 0 47 L 7 53 L 11 41 Q 8 27 0 34 Z',fill:'#f43f5e',stroke:'#fff1f2','stroke-width':1.3},g);
    svg('path',{d:'M 0 34 L 0 47 M -9 40 L 0 44 L 9 40',fill:'none',stroke:'#7f1d1d','stroke-width':1},g);
  }
}
function paintSectors(){
  const counts=new Map();
  if(state){for(const code of state.hits[state.turn]){if(sectors.has(code))counts.set(code,(counts.get(code)||0)+1)}}
  for(const [code,element] of sectors){const count=Math.min(counts.get(code)||0,3);element.setAttribute('fill',count?hitShades[count]:element.dataset.originalFill);element.setAttribute('stroke',count?'#fff2c6':'#82909b');element.setAttribute('stroke-width',count?1.8:.8);element.setAttribute('aria-label',code+' : '+(counts.get(code)||0)+' impact(s)')}
  paintDarts();
}
const NS='http://www.w3.org/2000/svg';function svg(tag,attrs,parent){let e=document.createElementNS(NS,tag);for(let [k,v] of Object.entries(attrs))e.setAttribute(k,v);parent.append(e);return e}
function drawBoard(){const b=$('board');svg('circle',{cx:0,cy:0,r:220,fill:'#101820',stroke:'#8291a5','stroke-width':3},b);for(let i=0;i<20;i++){let n=order[i],a1=(i-.5)*Math.PI/10,a2=(i+.5)*Math.PI/10;const rings=[[16,99,'S'+String(n).padStart(2,'0')+'I',n],[99,112,'T'+String(n).padStart(2,'0'),n*3],[112,164,'S'+String(n).padStart(2,'0')+'E',n],[164,178,'D'+String(n).padStart(2,'0'),n*2]];for(let j=0;j<rings.length;j++){const [r1,r2,code,score]=rings[j];let fill=j===1||j===3?(i%2?'#1b965c':'#c63444'):(i%2?'#efe6c9':'#222b36');let p=svg('path',{d:wedge(r1,r2,a1,a2),fill,stroke:'#82909b','stroke-width':.8},b);registerSector(code,p,r1,r2,i*Math.PI/10);p.onclick=()=>hit(code,score)}let [x,y]=polar(199,i*Math.PI/10);let t=svg('text',{x,y,fill:'white','font-size':15,'font-weight':'bold','text-anchor':'middle','dominant-baseline':'middle','pointer-events':'none'},b);t.textContent=n}for(let [r,fill,code,score] of [[16,'#1b965c','SBULL',25],[7,'#c63444','DBULL',50]]){let c=svg('circle',{cx:0,cy:0,r,fill,stroke:'#82909b','stroke-width':.8},b);registerSector(code,c,code==='DBULL'?0:7,code==='DBULL'?7:16,0);c.onclick=()=>hit(code,score)}dartLayer=svg('g',{id:'dart-layer'},b)}drawBoard();
function initial(){return {players:[identity,$('opponent').value],turn:0,darts:0,scores:[0,0],hits:[[],[]],history:[],revision:0,room}}
function emit(action){if(!state)return;const ev={...action,id:uid+':'+(++seq),source:uid,ts:Date.now()};apply(ev);channel?.postMessage(ev)}
function apply(ev){if(!state||state.history.some(x=>x.id===ev.id))return;if(ev.type==='hit'){if(state.darts>=3){note('Ignoré : 3 fléchettes déjà lancées');return}state.scores[state.turn]+=ev.score;state.hits[state.turn].push(ev.code);state.darts++;sound('hit')}else if(ev.type==='next'){state.turn=1-state.turn;state.darts=0;state.hits=[[],[]];sound('switch')}else if(ev.type==='reset'){state.scores=[0,0];state.hits=[[],[]];state.turn=0;state.darts=0;sound('switch')}else return;state.history.push(ev);state.revision++;render();note(`${ev.source===uid?'Moi':'Autre fenêtre'} : ${ev.type}${ev.code?' '+ev.code:''}`)}
function note(msg){const l=$('log');l.textContent=`${new Date().toLocaleTimeString()} ${msg}\n`+l.textContent.slice(0,4500)}
function render(){if(!state)return;paintSectors();for(let i=0;i<2;i++){$('p'+(i+1)).className='player'+(state.turn===i?' active':'');$('p'+(i+1)).innerHTML='';const strong=document.createElement('strong');strong.textContent=state.players[i];const score=document.createElement('div');score.className='score';score.textContent=state.scores[i];const hits=document.createElement('div');hits.className='hits';hits.textContent='Impacts : '+(state.hits[i].slice(-6).join(' · ')||'—');$('p'+(i+1)).append(strong,score,hits)}$('turn').textContent=`Fléchettes : ${state.darts}/3`;$('status').textContent='Au tour de : '+state.players[state.turn];$('miss').disabled=state.darts>=3;$('next').disabled=false}
function hit(code,score){if(!state)return;emit({type:'hit',code,score})}
$('miss').onclick=()=>hit('MISS',0);$('next').onclick=()=>emit({type:'next'});$('reset').onclick=()=>{if(confirm('Réinitialiser les scores et les tours ?'))emit({type:'reset'})};
$('join').onclick=()=>{if(!identity){alert('Choisis puis enregistre ton joueur habituel.');return}room=$('room').value.trim().toUpperCase();if(!room){alert('Indique un salon');return}channel?.close();channel=new BroadcastChannel('granboard-test-'+room);state=initial();state.room=room;channel.onmessage=({data:e})=>{if(e.type==='hello'){channel.postMessage({type:'snapshot',target:e.source,source:uid,state});return}if(e.type==='snapshot'&&e.target===uid&&e.state&&e.state.room===room){if(e.state.revision>=state.revision){state=e.state;render();note('État du salon reçu')}return}apply(e)};$('game').classList.remove('hidden');$('connection').textContent='Salon local : '+room;render();note('Salon ouvert · joueur '+identity);channel.postMessage({type:'hello',source:uid})};
$('leave').onclick=()=>{channel?.close();channel=null;state=null;$('game').classList.add('hidden');$('connection').textContent='Simulation locale'};
