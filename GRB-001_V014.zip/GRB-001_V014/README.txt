GRB-001 V006
Même configuration Firebase et mêmes règles V005. Liste des joueurs conservée. Salons V006 isolés des anciens salons. Annulation successive des hits (y compris après changement de tour), correction manuelle, départ volontaire et perte de connexion. Reconnexion au même salon avec le même joueur. Réinitialisation efface historique. TWO LINES coming soon. Tests réels sur deux appareils nécessaires.

V008 : contrôle version.json au lancement, retour menu et reprise ; contrôle manuel ; mise à jour volontaire hors partie. Conserve les chemins Firebase V006 et les préférences. Pour chaque future version, actualiser version.json, current dans update.js, les références de cache et le numéro affiché.

V008 : salons isolés roomsV008, présence toutes les 5 s, pause après 30 s, libération après 60 s ou 120 s sans action, recyclage à la prochaine ouverture après 5 min sans présence. Aucun changement de liste joueurs.

V010 : moteur et chemins Firebase V008 inchanges. Entree HTML versionnee, verification du HTML avant navigation, protection contre boucle. Pour chaque version future, publier index.html et index-VNNN.html identiques, meta granboard-version, version.json avec entry, et actualiser current et les references JS/CSS. Tester sur appareils reels.

V012 : service worker limité aux navigations Granboard, réseau prioritaire sans cache, adresse racine stable, alias versionné conservé pour les anciens clients. Pas de rechargement automatique pendant une partie. Première activation à vérifier sur iOS.

V013 : mode local deux joueurs, cible virtuelle partagée, état en mémoire, logs distincts. Sélection des joueurs via le registre Firebase existant. Bluetooth et vidéo non inclus.

V014 : choix cible individuel, préférences locales par joueur, modes synchronisés en réseau, Bluetooth simulé par saisie écran. Aucun accès Bluetooth réel. Tests appareils requis.
