(() => {
const current = 'V012';
const $ = id => document.getElementById(id);
const dialog = $('updateDialog');
const root = new URL('./', location.href);
const key = 'granboard-update-attempt';
let pending = null, dismissed = null, checking = false, updating = false;
const safe = () => !$('menu').classList.contains('hidden') && $('game').classList.contains('hidden');
const number = v => Number(v.slice(1));
const valid = v => typeof v === 'string' && /^V[0-9]{3,}$/.test(v);
const readAttempt = () => { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } };
const clearAttempt = () => { try { localStorage.removeItem(key); } catch {} };
const status = msg => { $('updateStatus').textContent = msg; };
async function check(manual = false) {
 if (!safe() || checking || updating) return;
 checking = true;
 if (manual) status('Vérification…');
 try {
  const url = new URL('version.json', root);
  url.searchParams.set('_', Date.now());
  const response = await fetch(url, {cache:'no-store'});
  if (!response.ok) throw Error('HTTP '+response.status);
  const {version, entry} = await response.json();
  if (!valid(version)) throw Error('Version invalide');
  const attempt = readAttempt();
  if (attempt && number(current) >= number(attempt.version)) clearAttempt();
  if (number(version) > number(current)) {
   pending = {version, entry: entry === 'index-'+version+'.html' ? entry : 'index.html'};
   const failed = attempt?.version === version && number(current) < number(version);
   status(failed ? 'Mise à jour non confirmée. Vérifie à nouveau manuellement.' : 'Nouvelle version : '+version);
   if (safe() && !dialog.open && !$('fkeDialog').open && (manual || (!failed && dismissed !== version))) {
    $('updateMessage').textContent = 'Version actuelle : '+current+' · Nouvelle version : '+version;
    dialog.showModal();
   }
  } else {
   pending = null;
   status(number(version) === number(current) ? 'Version '+current+' à jour' : 'Version publiée plus ancienne : '+version);
  }
 } catch { status('Vérification indisponible. Réessaie plus tard.'); }
 finally { checking = false; }
}
$('checkUpdate').onclick = () => check(true);
$('updateLater').onclick = () => { dismissed = pending?.version; dialog.close(); };
dialog.addEventListener('cancel', () => { dismissed = pending?.version; });
$('updateNow').onclick = async () => {
 if (!safe() || !pending || updating) return;
 updating = true;
 const target = pending;
 $('updateNow').disabled = true;
 $('updateLater').disabled = true;
 $('updateMessage').textContent = 'Vérification des nouveaux fichiers…';
 try {
  const url = new URL(target.entry, root);
  url.searchParams.set('v', target.version.slice(1));
  url.searchParams.set('_', Date.now());
  const response = await fetch(url, {cache:'no-store'});
  if (!response.ok) throw Error('HTTP '+response.status);
  const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
  if (doc.querySelector('meta[name="granboard-version"]')?.content !== target.version) throw Error('Version non disponible');
  if (!safe()) throw Error('Partie en cours');
  try { localStorage.setItem(key, JSON.stringify({version:target.version})); } catch {}
  window.dispatchEvent(new CustomEvent("fke-log",{detail:{type:"UPDATE",tool:"update",detail:"Mise à jour demandée"}}));
  const launch = new URL('./', root);
  launch.searchParams.set('v', target.version.slice(1));
  launch.searchParams.set('_', Date.now());
  location.replace(launch.href);
  setTimeout(() => {
   updating = false;
   $('updateNow').disabled = false;
   $('updateLater').disabled = false;
   if (dialog.open) dialog.close();
   status('Mise à jour non confirmée. Réessaie manuellement.');
  }, 10000);
 } catch {
  updating = false;
  dismissed = target.version;
  $('updateNow').disabled = false;
  $('updateLater').disabled = false;
  dialog.close();
  status('Nouvelle version pas encore accessible. Réessaie dans quelques instants.');
 }
};
window.addEventListener('granboard-menu', () => check());
window.addEventListener('pageshow', () => check());
document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
check();
})();
